# Student Academic Performance and Placement Analysis

An end-to-end beginner Python data analysis project using a reproducible **synthetic dataset** of student academic, training, placement, and salary information.

## Workflow
1. Dataset Creation
2. DataFrame Creation
3. Dataset Export
4. Data Inspection
5. Data Cleaning and Validation
6. Data Manipulation using Pandas
7. Pivot Table Analysis
8. Exploratory Data Analysis
9. Data Visualization using Matplotlib
10. Key Findings and Conclusion

## Tools
Python, NumPy, Pandas, Matplotlib, Jupyter Notebook.

## Dataset
The raw dataset contains 3,010 rows, including 3,000 generated student records and 10 intentionally added duplicate rows for cleaning practice. A small number of missing values and whitespace inconsistencies are also included intentionally. The cleaned dataset removes duplicates, standardizes text, fills selected missing values, and validates placement/package consistency.

All data is synthetic. It does not represent real students or actual placement outcomes. Simulated relationships are for practice only.

## Run
```bash
pip install -r requirements.txt
jupyter notebook Student_Academic_Performance_and_Placement_Analysis.ipynb
```

Run the notebook from top to bottom. It exports raw and cleaned data and saves charts in `visualizations/`.
